package run;

import view.MenuView;

public class Run {
	public static void main(String[] args) {
		new MenuView();
		//MemberController membercontroller = MemberController.getInstance();
	}
}	
